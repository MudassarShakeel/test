/* Johanna Shop Enhancer — AJAX shop (sidebar category tree, search, price/stock/sale filters, sort, load more) */
(function ($) {
	'use strict';
	if (typeof JNSE_SHOP === 'undefined') return;

	var P = JNSE_SHOP.params;
	var MOBILE = '(max-width: 991px)';

	function store(key, val) {
		try { if (val === undefined) return window.localStorage.getItem(key); window.localStorage.setItem(key, val); } catch (e) { return null; }
	}

	function Shop(root) {
		var $r = this.$root = $(root);
		this.home = $r.data('mode') === 'home';
		this.$grid = $r.find('[data-jnse-grid]');
		this.$count = $r.find('[data-jnse-count]');
		this.$empty = $r.find('[data-jnse-empty]');
		this.$more = $r.find('[data-jnse-more]');
		this.$all = $r.find('[data-jnse-all]');
		this.$search = $r.find('[data-jnse-search]');
		this.$sort = $r.find('[data-jnse-sort]');
		this.$min = $r.find('[data-jnse-min]');
		this.$max = $r.find('[data-jnse-max]');
		this.$stock = $r.find('[data-jnse-stock]');
		this.$sale = $r.find('[data-jnse-sale]');
		this.$title = $r.find('[data-jnse-title]');

		this.initialCat = String($r.data('cat') || '');
		this.archive = !this.home && $('body').hasClass('tax-product_cat');
		this.state = {
			cat: this.initialCat,
			search: String($r.data('search') || ''),
			orderby: String($r.data('orderby') || 'menu_order'),
			min: String($r.data('min') === undefined ? '' : $r.data('min')),
			max: String($r.data('max') === undefined ? '' : $r.data('max')),
			stock: +$r.data('stock') ? 1 : 0,
			sale: +$r.data('sale') ? 1 : 0,
			page: 1
		};
		this.perPage = parseInt($r.data('per-page'), 10) || 24;
		this.pages = parseInt($r.data('pages'), 10) || 1;
		this.defaultOrder = this.$sort.find('option').first().val();
		this.xhr = null;
		this.cache = {};
		this.timers = {};

		this.cache[this.key(this.state)] = { html: this.$grid.html(), pages: this.pages, countText: this.$count.text() };

		var view = store('jnse_view');
		if (view === 'list') this.setView('list');

		this.bind();
		this.observe();
	}

	Shop.prototype.key = function (s) {
		return [s.cat, s.search.toLowerCase(), s.orderby, s.min, s.max, s.stock, s.sale, s.page].join('|');
	};

	Shop.prototype.isMobile = function () { return window.matchMedia && window.matchMedia(MOBILE).matches; };

	Shop.prototype.bind = function () {
		var self = this, $r = this.$root;

		// Category tree: select
		$r.on('click', '.jnse-tree__link', function () {
			var cat = String($(this).data('cat') || '');
			if (cat !== self.state.cat) {
				self.state.cat = cat;
				self.setActiveCat(cat);
				self.update(true);
			}
			// Expand the clicked category's sub-list too (nice on touch devices)
			var $item = $(this).closest('.jnse-tree__item');
			if ($item.children('.jnse-tree__sub').length && !$item.hasClass('is-open')) self.toggleItem($item, true);
			if (self.isMobile() && !$(this).closest('.jnse-tree__item').children('.jnse-tree__sub').length) self.scrollToResults();
		});

		// Category tree: + / − toggles
		$r.on('click', '.jnse-tree__toggle', function () {
			var $item = $(this).closest('.jnse-tree__item');
			self.toggleItem($item, !$item.hasClass('is-open'));
		});

		// Search (desktop + mobile inputs stay in sync)
		this.$search.on('input', function () {
			var v = $.trim(this.value);
			self.$search.not(this).val(this.value);
			$r.find('[data-jnse-clear]').prop('hidden', v === '');
			self.debounce('search', 320, function () {
				if (v === self.state.search || v.length === 1) return;
				self.state.search = v;
				self.update(false);
			});
		});
		this.$search.on('keydown', function (e) {
			if (e.key === 'Escape') self.clearSearch();
			if (e.key === 'Enter') {
				e.preventDefault();
				clearTimeout(self.timers.search);
				self.state.search = $.trim(this.value);
				self.update(false);
				this.blur();
			}
		});
		$r.on('click', '[data-jnse-clear]', function () { self.clearSearch(); });

		// Sort
		this.$sort.on('change', function () { self.state.orderby = this.value; self.update(true); });

		// Price
		this.$min.add(this.$max).on('input', function () {
			self.debounce('price', 650, function () { self.readPrice(); });
		}).on('change', function () { clearTimeout(self.timers.price); self.readPrice(); });

		// Stock / sale
		this.$stock.on('change', function () { self.state.stock = this.checked ? 1 : 0; self.update(true); });
		this.$sale.on('change', function () { self.state.sale = this.checked ? 1 : 0; self.update(true); });

		// Load more
		this.$more.on('click', function () { self.loadMore(); });

		// Reset
		$r.on('click', '[data-jnse-reset]', function () { self.reset(); });

		// Mobile panel
		$r.on('click', '[data-jnse-panel-toggle]', function () {
			self.panel(!$r.hasClass('is-panel-open'));
			if (!$r.hasClass('is-panel-open') && $(this).hasClass('jnse-side__done')) self.scrollToResults();
		});

		// Grid / list view
		$r.on('click', '[data-jnse-view]', function () {
			var v = $(this).data('jnse-view');
			self.setView(v);
			store('jnse_view', v);
		});

		// Browser back / forward (shop page only)
		if (!this.home) {
			$(window).on('popstate', function () { self.fromUrl(); });
		}
	};

	Shop.prototype.debounce = function (name, ms, fn) {
		clearTimeout(this.timers[name]);
		this.timers[name] = setTimeout(fn, ms);
	};

	Shop.prototype.readPrice = function () {
		var min = $.trim(this.$min.val()), max = $.trim(this.$max.val());
		if (min === this.state.min && max === this.state.max) return;
		this.state.min = min; this.state.max = max;
		this.update(false);
	};

	Shop.prototype.clearSearch = function () {
		this.$search.val('');
		this.$root.find('[data-jnse-clear]').prop('hidden', true);
		if (this.state.search !== '') { this.state.search = ''; this.update(false); }
	};

	Shop.prototype.reset = function () {
		$.extend(this.state, { cat: '', search: '', min: '', max: '', stock: 0, sale: 0 });
		this.$search.val(''); this.$root.find('[data-jnse-clear]').prop('hidden', true);
		this.$min.val(''); this.$max.val('');
		this.$stock.prop('checked', false); this.$sale.prop('checked', false);
		this.setActiveCat('');
		this.update(true);
	};

	Shop.prototype.fromUrl = function () {
		var u = new URL(window.location.href);
		this.state.cat = u.searchParams.get(P.cat) || (this.archive ? this.initialCat : '');
		this.state.search = u.searchParams.get(P.search) || '';
		this.state.orderby = u.searchParams.get(P.order) || this.defaultOrder;
		this.state.min = u.searchParams.get(P.min) || '';
		this.state.max = u.searchParams.get(P.max) || '';
		this.state.stock = u.searchParams.get(P.stock) ? 1 : 0;
		this.state.sale = u.searchParams.get(P.sale) ? 1 : 0;
		this.state.page = 1;
		this.$search.val(this.state.search); this.$root.find('[data-jnse-clear]').prop('hidden', !this.state.search);
		this.$sort.val(this.state.orderby);
		this.$min.val(this.state.min); this.$max.val(this.state.max);
		this.$stock.prop('checked', !!this.state.stock); this.$sale.prop('checked', !!this.state.sale);
		this.setActiveCat(this.state.cat);
		this.refreshUi();
		this.fetch(false);
	};

	Shop.prototype.toggleItem = function ($item, open) {
		$item.toggleClass('is-open', open);
		$item.children('.jnse-tree__row').find('.jnse-tree__toggle').attr('aria-expanded', open ? 'true' : 'false');
		$item.children('.jnse-tree__sub').prop('hidden', !open);
	};

	Shop.prototype.setActiveCat = function (cat) {
		var self = this;
		var $links = this.$root.find('.jnse-tree__link');
		$links.removeClass('is-active').attr('aria-pressed', 'false');
		var $a = $links.filter(function () { return String($(this).data('cat') || '') === cat; }).first();
		$a.addClass('is-active').attr('aria-pressed', 'true');
		// open ancestors
		$a.parents('.jnse-tree__item').each(function (i) {
			if (i > 0) self.toggleItem($(this), true);
		});
		if (this.$title.length && !this.home) {
			this.$title.text($a.data('name') || this.$title.data('default') || this.$title.text());
		}
	};

	Shop.prototype.setView = function (v) {
		this.$root.toggleClass('jnse--list', v === 'list');
		this.$root.find('[data-jnse-view]').each(function () {
			var on = $(this).data('jnse-view') === v;
			$(this).toggleClass('is-active', on).attr('aria-pressed', on ? 'true' : 'false');
		});
	};

	Shop.prototype.panel = function (open) {
		this.$root.toggleClass('is-panel-open', open);
		this.$root.find('.jnse-mbar__btn').attr('aria-expanded', open ? 'true' : 'false');
	};

	Shop.prototype.scrollToResults = function () {
		var $t = this.$root.find('.jnse-toolbar');
		if (!$t.length) return;
		var top = $t.offset().top - 16;
		if (Math.abs($(window).scrollTop() - top) > 80) window.scrollTo({ top: top, behavior: 'smooth' });
	};

	Shop.prototype.activeCount = function () {
		var s = this.state;
		return (s.cat ? 1 : 0) + (s.search ? 1 : 0) + ((s.min || s.max) ? 1 : 0) + s.stock + s.sale;
	};

	Shop.prototype.refreshUi = function () {
		var n = this.activeCount();
		this.$root.find('[data-jnse-badge]').text(n).prop('hidden', !n);
		this.$root.find('.jnse-clear[data-jnse-reset]').prop('hidden', !n);
		if (this.$all.length) this.$all.attr('href', this.url().toString());
	};

	Shop.prototype.url = function () {
		var s = this.state;
		var u = new URL(JNSE_SHOP.shopUrl, window.location.origin);
		if (this.archive && s.cat && s.cat === this.initialCat) {
			u = new URL(window.location.href.split('?')[0]);
		} else if (s.cat) {
			u.searchParams.set(P.cat, s.cat);
		}
		if (s.search) u.searchParams.set(P.search, s.search);
		if (s.orderby && s.orderby !== this.defaultOrder) u.searchParams.set(P.order, s.orderby);
		if (s.min) u.searchParams.set(P.min, s.min);
		if (s.max) u.searchParams.set(P.max, s.max);
		if (s.stock) u.searchParams.set(P.stock, 1);
		if (s.sale) u.searchParams.set(P.sale, 1);
		return u;
	};

	// New filter → page 1, replace grid, update URL / badges.
	Shop.prototype.update = function (push) {
		this.state.page = 1;
		this.refreshUi();
		if (!this.home && window.history && history.replaceState) {
			history[push ? 'pushState' : 'replaceState']({ jnse: 1 }, '', this.url().toString());
		}
		this.fetch(false);
	};

	Shop.prototype.loadMore = function () {
		if (this.home || this.xhr || this.state.page >= this.pages) return;
		this.state.page += 1;
		this.fetch(true);
	};

	Shop.prototype.skeleton = function () {
		var html = '';
		for (var i = 0; i < Math.min(8, this.perPage); i++) {
			html += '<div class="jnse-skel"><div class="jnse-skel__img"></div><div class="jnse-skel__line"></div><div class="jnse-skel__line is-short"></div></div>';
		}
		return html;
	};

	Shop.prototype.fetch = function (append) {
		var self = this;
		var s = $.extend({}, this.state);
		var k = this.key(s);

		if (this.xhr) { this.xhr.abort(); this.xhr = null; }

		if (this.cache[k]) {
			this.$root.removeClass('is-loading is-appending is-replacing');
			this.render(this.cache[k], append);
			if (append) this.observe();
			return;
		}

		this.$root.addClass('is-loading ' + (append ? 'is-appending' : 'is-replacing'));
		this.$grid.attr('aria-busy', 'true');
		if (!append && !this.$grid.children().length) this.$grid.html(this.skeleton());

		this.xhr = $.ajax({
			url: JNSE_SHOP.endpoint,
			method: 'GET',
			dataType: 'json',
			data: { cat: s.cat, search: s.search, orderby: s.orderby, min: s.min, max: s.max, stock: s.stock, sale: s.sale, page: s.page, per_page: this.perPage }
		}).done(function (res) {
			if (!res || !res.success) return self.fail(append);
			self.cache[k] = res.data;
			self.render(res.data, append);
		}).fail(function (x, status) {
			if (status !== 'abort') self.fail(append);
		}).always(function (x, status) {
			if (status === 'abort') return;
			self.xhr = null;
			self.$root.removeClass('is-loading is-appending is-replacing');
			self.$grid.attr('aria-busy', 'false');
			self.observe();
		});
	};

	Shop.prototype.fail = function (append) {
		if (append) this.state.page = Math.max(1, this.state.page - 1);
		this.$count.text(JNSE_SHOP.i18n.error);
	};

	Shop.prototype.render = function (d, append) {
		if (append) this.$grid.append(d.html); else this.$grid.html(d.html);
		this.pages = d.pages;
		this.$count.text(d.countText);
		var empty = !append && $.trim(d.html) === '';
		this.$empty.prop('hidden', !empty);
		this.$more.prop('hidden', this.state.page >= this.pages || empty);
		this.$all.prop('hidden', empty);
		$(document.body).trigger('jnse:rendered', [this.$grid, d]);
	};

	// Infinite scroll (shop page only)
	Shop.prototype.observe = function () {
		var self = this;
		if (this.home || !JNSE_SHOP.infinite || !('IntersectionObserver' in window)) return;
		var s = this.$root.find('[data-jnse-sentinel]')[0];
		if (!s) return;
		if (!this.io) {
			this.io = new IntersectionObserver(function (entries) {
				entries.forEach(function (e) { if (e.isIntersecting) self.loadMore(); });
			}, { rootMargin: '600px 0px' });
			this.io.observe(s);
			return;
		}
		requestAnimationFrame(function () {
			if (s.getBoundingClientRect().top < window.innerHeight + 600) self.loadMore();
		});
	};

	$(function () {
		$('[data-jnse]').each(function () { new Shop(this); });
	});
})(jQuery);
