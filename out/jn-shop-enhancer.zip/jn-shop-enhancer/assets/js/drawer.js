/* Johanna Shop Enhancer — mini-cart drawer */
(function ($) {
	'use strict';

	var $body = $(document.body);
	var lastFocus = null;

	function $drawer() { return $('#jnse-drawer'); }

	function open() {
		var $d = $drawer();
		if (!$d.length || $d.hasClass('is-open')) return;
		lastFocus = document.activeElement;
		$('.jnse-overlay').prop('hidden', false);
		// next frame so the transition runs
		requestAnimationFrame(function () {
			$('.jnse-overlay').addClass('is-open');
			$d.addClass('is-open').attr('aria-hidden', 'false');
			$('html').addClass('jnse-lock');
			setTimeout(function () { $d.trigger('focus'); }, 50);
		});
	}

	function close() {
		var $d = $drawer();
		if (!$d.hasClass('is-open')) return;
		$d.removeClass('is-open').attr('aria-hidden', 'true');
		$('.jnse-overlay').removeClass('is-open');
		$('html').removeClass('jnse-lock');
		setTimeout(function () { $('.jnse-overlay').prop('hidden', true); }, 300);
		if (lastFocus && lastFocus.focus) lastFocus.focus();
	}

	function applyFragments(fragments) {
		if (!fragments) return;
		$.each(fragments, function (sel, html) { $(sel).replaceWith(html); });
	}

	function bump() {
		var $c = $('.jnse-fab');
		$c.removeClass('is-bump');
		if ($c[0]) void $c[0].offsetWidth; // force reflow to restart animation
		$c.addClass('is-bump');
	}

	function updateQty($item, qty) {
		var nonce = $('.jnse-drawer__body').data('nonce');
		$item.addClass('is-busy');
		$.post(JNSE_CART.endpoint, { key: $item.data('key'), qty: qty, nonce: nonce })
			.done(function (res) {
				if (res && res.fragments) {
					applyFragments(res.fragments);
					// Lets WooCommerce's cart-fragments script store the new cart in sessionStorage.
					$body.trigger('removed_from_cart', [res.fragments, res.cart_hash, null]);
				} else {
					$body.trigger('wc_fragment_refresh');
				}
			})
			.fail(function () { $body.trigger('wc_fragment_refresh'); })
			.always(function () { $item.removeClass('is-busy'); });
	}

	// Open triggers: floating button + any element with .jnse-open-cart (add it to your header cart icon).
	$(document).on('click', '.jnse-open-cart', function (e) { e.preventDefault(); open(); });
	$(document).on('click', '[data-jnse-close]', function () { close(); });
	$(document).on('keydown', function (e) {
		if (e.key === 'Escape') close();
		// Simple focus trap
		if (e.key === 'Tab' && $drawer().hasClass('is-open')) {
			var f = $drawer().find('a[href], button:not([disabled]), input, select').filter(':visible');
			if (!f.length) return;
			var first = f[0], last = f[f.length - 1];
			if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
			else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
		}
	});

	// Quantity +/- and remove
	$(document).on('click', '#jnse-drawer [data-jnse-qty]', function () {
		var $item = $(this).closest('.jnse-item');
		if ($item.hasClass('is-busy')) return;
		var cur = parseInt($item.find('[data-qty]').data('qty'), 10) || 1;
		var next = cur + parseInt($(this).data('jnse-qty'), 10);
		var max = parseInt($(this).data('max'), 10) || 9999;
		next = Math.max(0, Math.min(max, next));
		$item.find('[data-qty]').text(next);
		updateQty($item, next);
	});
	$(document).on('click', '#jnse-drawer [data-jnse-remove]', function () {
		var $item = $(this).closest('.jnse-item');
		if ($item.hasClass('is-busy')) return;
		$item.addClass('is-removing');
		updateQty($item, 0);
	});

	// WooCommerce fires this after an AJAX add-to-cart.
	$body.on('added_to_cart', function (e, fragments) {
		applyFragments(fragments);
		bump();
		open();
	});
})(jQuery);
