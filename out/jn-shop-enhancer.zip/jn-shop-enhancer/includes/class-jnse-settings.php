<?php
defined( 'ABSPATH' ) || exit;

/**
 * Settings page (WooCommerce → Johanna Shop) + CSS variable output.
 */
class JNSE_Settings {

	const OPTION = 'jnse_settings';

	public static function defaults() {
		return array(
			// Colors — replace with the theme's hex codes.
			'color_primary'       => '#1c1c1c', // buttons, active pill, links
			'color_primary_hover' => '#3a3a3a',
			'color_on_primary'    => '#ffffff', // text on primary buttons
			'color_accent'        => '#c9a189', // badges, highlights, focus ring
			'color_text'          => '#1f1f1f',
			'color_muted'         => '#77706b',
			'color_bg'            => '#ffffff',
			'color_surface'       => '#f8f5f2', // card image bg, panels
			'color_border'        => '#e9e3de',
			'color_sale'          => '#b5473a',
			// Typography — "inherit" keeps the theme's fonts.
			'font_heading'        => 'inherit',
			'font_body'           => 'inherit',
			'radius'              => 14,
			// Shop page.
			'replace_shop'        => 1,
			'replace_cat_pages'   => 1,
			'per_page'            => 24,
			'cols_desktop'        => 3,
			'cols_tablet'         => 3,
			'cols_mobile'         => 2,
			'infinite_scroll'     => 1,
			'image_ratio'         => '1/1', // 1/1, 4/5, 3/4
			'hide_uncategorized'  => 1,
			'shop_title'          => 'Tienda',
			'shop_subtitle'       => '',
			// Cart.
			'drawer'              => 1,
			'free_ship_threshold' => 0,
			'style_cart'          => 1,
			'style_checkout'      => 1,
		);
	}

	public static function get( $key = null ) {
		static $cache = null;
		if ( null === $cache ) {
			$cache = wp_parse_args( (array) get_option( self::OPTION, array() ), self::defaults() );
		}
		return null === $key ? $cache : ( $cache[ $key ] ?? null );
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 99 );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin_assets' ) );
		add_action( 'wp_head', array( __CLASS__, 'css_vars' ), 99 );
	}

	public static function menu() {
		add_submenu_page( 'woocommerce', 'Johanna Shop', 'Johanna Shop', 'manage_woocommerce', 'jn-shop', array( __CLASS__, 'page' ) );
	}

	public static function admin_assets( $hook ) {
		if ( false === strpos( (string) $hook, 'jn-shop' ) ) {
			return;
		}
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );
		wp_add_inline_script( 'wp-color-picker', 'jQuery(function($){$(".jnse-color").wpColorPicker();});' );
	}

	public static function register() {
		register_setting( 'jnse', self::OPTION, array( 'sanitize_callback' => array( __CLASS__, 'sanitize' ) ) );
	}

	public static function sanitize( $in ) {
		$d   = self::defaults();
		$out = array();
		foreach ( $d as $k => $def ) {
			$v = $in[ $k ] ?? null;
			if ( 0 === strpos( $k, 'color_' ) ) {
				$out[ $k ] = sanitize_hex_color( $v ) ?: $def;
			} elseif ( is_int( $def ) ) {
				$out[ $k ] = absint( $v );
			} else {
				$out[ $k ] = sanitize_text_field( (string) $v );
			}
		}
		$out['per_page']     = max( 4, min( 100, $out['per_page'] ?: 24 ) );
		$out['cols_desktop'] = max( 2, min( 6, $out['cols_desktop'] ?: 3 ) );
		$out['cols_tablet']  = max( 1, min( 4, $out['cols_tablet'] ?: 3 ) );
		$out['cols_mobile']  = max( 1, min( 2, $out['cols_mobile'] ?: 2 ) );
		$out['radius']       = min( 40, $out['radius'] );
		if ( ! in_array( $out['image_ratio'], array( '1/1', '4/5', '3/4' ), true ) ) {
			$out['image_ratio'] = '1/1';
		}
		// Fonts: allow only safe characters for a CSS font-family list.
		foreach ( array( 'font_heading', 'font_body' ) as $f ) {
			$out[ $f ] = preg_replace( '/[^a-zA-Z0-9 ,\'"\-]/', '', $out[ $f ] ) ?: 'inherit';
		}
		return $out;
	}

	/** Print CSS custom properties used by every stylesheet in the plugin. */
	public static function css_vars() {
		$s = self::get();
		$css  = ':root{';
		$css .= '--jn-primary:' . $s['color_primary'] . ';';
		$css .= '--jn-primary-hover:' . $s['color_primary_hover'] . ';';
		$css .= '--jn-on-primary:' . $s['color_on_primary'] . ';';
		$css .= '--jn-accent:' . $s['color_accent'] . ';';
		$css .= '--jn-text:' . $s['color_text'] . ';';
		$css .= '--jn-muted:' . $s['color_muted'] . ';';
		$css .= '--jn-bg:' . $s['color_bg'] . ';';
		$css .= '--jn-surface:' . $s['color_surface'] . ';';
		$css .= '--jn-border:' . $s['color_border'] . ';';
		$css .= '--jn-sale:' . $s['color_sale'] . ';';
		$css .= '--jn-font-heading:' . $s['font_heading'] . ';';
		$css .= '--jn-font-body:' . $s['font_body'] . ';';
		$css .= '--jn-radius:' . (int) $s['radius'] . 'px;';
		$css .= '--jn-cols:' . (int) $s['cols_desktop'] . ';';
		$css .= '--jn-cols-t:' . (int) $s['cols_tablet'] . ';';
		$css .= '--jn-cols-m:' . (int) $s['cols_mobile'] . ';';
		$css .= '--jn-ratio:' . $s['image_ratio'] . ';';
		$css .= '}';
		echo "<style id=\"jnse-vars\">{$css}</style>\n"; // phpcs:ignore -- values sanitized on save.
	}

	public static function page() {
		$s = self::get();
		$n = self::OPTION;

		$colors = array(
			'color_primary'       => 'Primary (buttons, active filter)',
			'color_primary_hover' => 'Primary hover',
			'color_on_primary'    => 'Text on primary',
			'color_accent'        => 'Accent (badges, highlights)',
			'color_text'          => 'Text',
			'color_muted'         => 'Muted text',
			'color_bg'            => 'Background',
			'color_surface'       => 'Surface (image & panel background)',
			'color_border'        => 'Borders',
			'color_sale'          => 'Sale badge / sale price',
		);
		$checkbox = function ( $key, $label ) use ( $s, $n ) {
			printf(
				'<label><input type="hidden" name="%1$s[%2$s]" value="0"><input type="checkbox" name="%1$s[%2$s]" value="1" %3$s> %4$s</label><br>',
				esc_attr( $n ), esc_attr( $key ), checked( 1, (int) $s[ $key ], false ), esc_html( $label )
			);
		};
		$number = function ( $key, $min, $max ) use ( $s, $n ) {
			printf( '<input type="number" min="%3$d" max="%4$d" name="%1$s[%2$s]" value="%5$d" class="small-text">', esc_attr( $n ), esc_attr( $key ), $min, $max, (int) $s[ $key ] );
		};
		?>
		<div class="wrap">
			<h1>Johanna Shop Enhancer</h1>
			<p><strong>Home page block:</strong> <code>[jn_shop_home limit="8" title="Nuestros productos" button="Ver todos los productos"]</code><br>
			Options: <code>limit</code> (products shown), <code>columns</code>, <code>category="slug"</code>, <code>orderby="date|popularity|price|price-desc|rating"</code>, <code>filters="no"</code> (hide the sidebar).</p>
			<p><strong>Full shop anywhere:</strong> <code>[jn_shop]</code> — only needed if you turn off automatic shop replacement. Optional: <code>category="slug"</code>, <code>per_page="24"</code>.</p>
			<form method="post" action="options.php">
				<?php settings_fields( 'jnse' ); ?>
				<h2>Colors &amp; style</h2>
				<table class="form-table" role="presentation">
					<?php foreach ( $colors as $key => $label ) : ?>
						<tr><th scope="row"><?php echo esc_html( $label ); ?></th>
							<td><input type="text" class="jnse-color" name="<?php echo esc_attr( "{$n}[{$key}]" ); ?>" value="<?php echo esc_attr( $s[ $key ] ); ?>" data-default-color="<?php echo esc_attr( self::defaults()[ $key ] ); ?>"></td></tr>
					<?php endforeach; ?>
					<tr><th scope="row">Heading font</th><td><input type="text" class="regular-text" name="<?php echo esc_attr( "{$n}[font_heading]" ); ?>" value="<?php echo esc_attr( $s['font_heading'] ); ?>"><p class="description"><code>inherit</code> = use the theme font. Or e.g. <code>"Playfair Display", serif</code></p></td></tr>
					<tr><th scope="row">Body font</th><td><input type="text" class="regular-text" name="<?php echo esc_attr( "{$n}[font_body]" ); ?>" value="<?php echo esc_attr( $s['font_body'] ); ?>"></td></tr>
					<tr><th scope="row">Corner radius (px)</th><td><?php $number( 'radius', 0, 40 ); ?></td></tr>
				</table>

				<h2>Shop page</h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row">Replace pages</th><td>
						<?php $checkbox( 'replace_shop', 'Replace the WooCommerce shop page with the AJAX shop' ); ?>
						<?php $checkbox( 'replace_cat_pages', 'Also use it on product category pages (category pre-selected)' ); ?>
					</td></tr>
					<tr><th scope="row">Title / subtitle</th><td>
						<input type="text" class="regular-text" name="<?php echo esc_attr( "{$n}[shop_title]" ); ?>" value="<?php echo esc_attr( $s['shop_title'] ); ?>"><br><br>
						<input type="text" class="large-text" placeholder="Optional subtitle" name="<?php echo esc_attr( "{$n}[shop_subtitle]" ); ?>" value="<?php echo esc_attr( $s['shop_subtitle'] ); ?>">
					</td></tr>
					<tr><th scope="row">Products per load</th><td><?php $number( 'per_page', 4, 100 ); ?></td></tr>
					<tr><th scope="row">Columns</th><td>Desktop <?php $number( 'cols_desktop', 2, 6 ); ?> &nbsp; Tablet <?php $number( 'cols_tablet', 1, 4 ); ?> &nbsp; Mobile <?php $number( 'cols_mobile', 1, 2 ); ?></td></tr>
					<tr><th scope="row">Image shape</th><td>
						<select name="<?php echo esc_attr( "{$n}[image_ratio]" ); ?>">
							<?php foreach ( array( '1/1' => 'Square', '4/5' => 'Portrait 4:5', '3/4' => 'Portrait 3:4' ) as $v => $l ) : ?>
								<option value="<?php echo esc_attr( $v ); ?>" <?php selected( $s['image_ratio'], $v ); ?>><?php echo esc_html( $l ); ?></option>
							<?php endforeach; ?>
						</select>
					</td></tr>
					<tr><th scope="row">Options</th><td>
						<?php $checkbox( 'infinite_scroll', 'Load more products automatically while scrolling (a button is always shown as fallback)' ); ?>
						<?php $checkbox( 'hide_uncategorized', 'Hide the default "Uncategorized" category' ); ?>
					</td></tr>
				</table>

				<h2>Cart &amp; checkout</h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row">Mini-cart</th><td><?php $checkbox( 'drawer', 'Slide-in mini-cart drawer + floating cart button (opens after add to cart)' ); ?></td></tr>
					<tr><th scope="row">Free shipping bar</th><td><?php $number( 'free_ship_threshold', 0, 100000 ); ?> <p class="description">Order amount for free shipping, shown as a progress bar in the drawer and cart. 0 = hidden.</p></td></tr>
					<tr><th scope="row">Restyle</th><td>
						<?php $checkbox( 'style_cart', 'Restyle the cart page' ); ?>
						<?php $checkbox( 'style_checkout', 'Restyle the checkout page' ); ?>
					</td></tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}
