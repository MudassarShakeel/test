<?php
defined( 'ABSPATH' ) || exit;

/**
 * Mini-cart drawer, cart fragments, quantity AJAX, cart/checkout styling.
 */
class JNSE_Cart {

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ), 25 );
		add_action( 'wp_footer', array( __CLASS__, 'drawer' ), 5 );
		add_filter( 'woocommerce_add_to_cart_fragments', array( __CLASS__, 'fragments' ) );
		add_action( 'wc_ajax_jnse_update_qty', array( __CLASS__, 'ajax_update_qty' ) );
		add_filter( 'body_class', array( __CLASS__, 'body_class' ) );

		// Free-shipping progress on the classic cart page.
		add_action( 'woocommerce_before_cart_table', array( __CLASS__, 'print_free_shipping' ) );
		add_action( 'woocommerce_before_checkout_form', array( __CLASS__, 'checkout_steps' ), 1 );
	}

	protected static function drawer_enabled() {
		return (bool) JNSE_Settings::get( 'drawer' ) && ! is_cart() && ! is_checkout();
	}

	public static function body_class( $classes ) {
		if ( is_cart() && JNSE_Settings::get( 'style_cart' ) ) {
			$classes[] = 'jnse-cart-page';
		}
		if ( is_checkout() && JNSE_Settings::get( 'style_checkout' ) ) {
			$classes[] = 'jnse-checkout-page';
		}
		return $classes;
	}

	public static function assets() {
		if ( self::drawer_enabled() ) {
			wp_enqueue_style( 'jnse-drawer', JNSE_URL . 'assets/css/drawer.css', array(), JNSE_VERSION );
			wp_enqueue_script( 'wc-cart-fragments' ); // not loaded by default since WC 7.8
			wp_enqueue_script( 'jnse-drawer', JNSE_URL . 'assets/js/drawer.js', array( 'jquery', 'wc-cart-fragments' ), JNSE_VERSION, true );
			wp_localize_script( 'jnse-drawer', 'JNSE_CART', array(
				'endpoint' => WC_AJAX::get_endpoint( 'jnse_update_qty' ),
			) );
		}
		if ( ( is_cart() && JNSE_Settings::get( 'style_cart' ) ) || ( is_checkout() && JNSE_Settings::get( 'style_checkout' ) ) ) {
			wp_enqueue_style( 'jnse-cart-checkout', JNSE_URL . 'assets/css/cart-checkout.css', array(), JNSE_VERSION );
		}
	}

	/* ---------------------------------------------------------------------
	 * Drawer
	 * ------------------------------------------------------------------- */

	public static function count_html() {
		$n = WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
		return '<span class="jnse-cart-count" data-count="' . (int) $n . '">' . (int) $n . '</span>';
	}

	public static function drawer() {
		if ( ! self::drawer_enabled() ) {
			return;
		}
		?>
		<button type="button" class="jnse-fab jnse-open-cart" aria-label="<?php esc_attr_e( 'Abrir carrito', 'jn-shop' ); ?>" aria-controls="jnse-drawer">
			<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 4h1.3c.6 0 1.1.4 1.3 1l1.9 7.6c.2.7.8 1.1 1.5 1.1h7.3c.7 0 1.3-.4 1.5-1.1l1.1-4.3c.2-.8-.3-1.3-1-1.3H8"/><circle cx="9.5" cy="18.5" r="1.6"/><circle cx="16" cy="18.5" r="1.6"/></svg>
			<?php echo self::count_html(); // phpcs:ignore ?>
		</button>
		<div class="jnse-overlay" data-jnse-close hidden></div>
		<aside id="jnse-drawer" class="jnse-drawer" role="dialog" aria-modal="true" aria-labelledby="jnse-drawer-title" aria-hidden="true" tabindex="-1">
			<header class="jnse-drawer__head">
				<h2 id="jnse-drawer-title"><?php esc_html_e( 'Tu carrito', 'jn-shop' ); ?></h2>
				<button type="button" class="jnse-drawer__close" data-jnse-close aria-label="<?php esc_attr_e( 'Cerrar', 'jn-shop' ); ?>">&times;</button>
			</header>
			<?php echo self::drawer_body(); // phpcs:ignore ?>
		</aside>
		<?php
	}

	public static function free_shipping_html() {
		$threshold = (float) JNSE_Settings::get( 'free_ship_threshold' );
		if ( $threshold <= 0 || ! WC()->cart || WC()->cart->is_empty() ) {
			return '';
		}
		$subtotal = (float) WC()->cart->get_displayed_subtotal();
		$left     = max( 0, $threshold - $subtotal );
		$pct      = min( 100, round( $subtotal / $threshold * 100 ) );
		$msg      = $left > 0
			/* translators: %s amount */
			? sprintf( __( 'Te faltan %s para el envío gratis', 'jn-shop' ), '<strong>' . wc_price( $left ) . '</strong>' )
			: '<strong>' . esc_html__( '¡Tienes envío gratis!', 'jn-shop' ) . '</strong>';

		return '<div class="jnse-freeship' . ( $left > 0 ? '' : ' is-done' ) . '"><p>' . wp_kses_post( $msg ) . '</p><div class="jnse-freeship__bar"><span style="width:' . (int) $pct . '%"></span></div></div>';
	}

	public static function print_free_shipping() {
		echo self::free_shipping_html(); // phpcs:ignore
	}

	public static function drawer_body() {
		$cart = WC()->cart;
		ob_start();
		echo '<div class="jnse-drawer__body" data-nonce="' . esc_attr( wp_create_nonce( 'jnse-cart' ) ) . '">';

		if ( ! $cart || $cart->is_empty() ) {
			?>
			<div class="jnse-drawer__empty">
				<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 7h12l-1 13H7L6 7Z"/><path d="M9 7a3 3 0 0 1 6 0"/></svg>
				<p><?php esc_html_e( 'Tu carrito está vacío', 'jn-shop' ); ?></p>
				<a class="jnse-dbtn" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>"><?php esc_html_e( 'Ir a la tienda', 'jn-shop' ); ?></a>
			</div>
			<?php
		} else {
			echo self::free_shipping_html(); // phpcs:ignore
			echo '<ul class="jnse-items">';
			foreach ( $cart->get_cart() as $key => $item ) {
				$p = apply_filters( 'woocommerce_cart_item_product', $item['data'], $item, $key );
				if ( ! $p || ! $p->exists() || $item['quantity'] <= 0 || ! apply_filters( 'woocommerce_widget_cart_item_visible', true, $item, $key ) ) {
					continue;
				}
				$link  = $p->is_visible() ? $p->get_permalink( $item ) : '';
				$max   = $p->get_max_purchase_quantity();
				$max   = $max > 0 ? $max : 9999;
				$sold1 = $p->is_sold_individually();
				?>
				<li class="jnse-item" data-key="<?php echo esc_attr( $key ); ?>">
					<a class="jnse-item__img" href="<?php echo esc_url( $link ?: '#' ); ?>"><?php echo $p->get_image( 'woocommerce_thumbnail' ); // phpcs:ignore ?></a>
					<div class="jnse-item__info">
						<a class="jnse-item__name" href="<?php echo esc_url( $link ?: '#' ); ?>"><?php echo wp_kses_post( $p->get_name() ); ?></a>
						<?php echo wc_get_formatted_cart_item_data( $item ); // phpcs:ignore ?>
						<div class="jnse-item__row">
							<?php if ( $sold1 ) : ?>
								<span class="jnse-item__qtytext">&times; 1</span>
							<?php else : ?>
								<div class="jnse-qty" role="group" aria-label="<?php esc_attr_e( 'Cantidad', 'jn-shop' ); ?>">
									<button type="button" data-jnse-qty="-1" aria-label="<?php esc_attr_e( 'Restar uno', 'jn-shop' ); ?>">&minus;</button>
									<span data-qty="<?php echo (int) $item['quantity']; ?>"><?php echo (int) $item['quantity']; ?></span>
									<button type="button" data-jnse-qty="1" data-max="<?php echo (int) $max; ?>" aria-label="<?php esc_attr_e( 'Sumar uno', 'jn-shop' ); ?>" <?php disabled( $item['quantity'] >= $max ); ?>>+</button>
								</div>
							<?php endif; ?>
							<span class="jnse-item__price"><?php echo $cart->get_product_subtotal( $p, $item['quantity'] ); // phpcs:ignore ?></span>
						</div>
					</div>
					<button type="button" class="jnse-item__remove" data-jnse-remove aria-label="<?php echo esc_attr( sprintf( /* translators: %s product */ __( 'Eliminar %s', 'jn-shop' ), wp_strip_all_tags( $p->get_name() ) ) ); ?>">
						<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>
					</button>
				</li>
				<?php
			}
			echo '</ul>';
			?>
			<footer class="jnse-drawer__foot">
				<div class="jnse-subtotal">
					<span><?php esc_html_e( 'Subtotal', 'jn-shop' ); ?></span>
					<strong><?php echo $cart->get_cart_subtotal(); // phpcs:ignore ?></strong>
				</div>
				<p class="jnse-drawer__note"><?php esc_html_e( 'Impuestos y envío calculados al finalizar la compra.', 'jn-shop' ); ?></p>
				<a class="jnse-dbtn" href="<?php echo esc_url( wc_get_checkout_url() ); ?>"><?php esc_html_e( 'Finalizar compra', 'jn-shop' ); ?></a>
				<a class="jnse-dbtn jnse-dbtn--ghost" href="<?php echo esc_url( wc_get_cart_url() ); ?>"><?php esc_html_e( 'Ver carrito', 'jn-shop' ); ?></a>
			</footer>
			<?php
		}
		echo '</div>';
		return ob_get_clean();
	}

	public static function fragments( $fragments ) {
		$fragments['span.jnse-cart-count']    = self::count_html();
		$fragments['div.jnse-drawer__body'] = self::drawer_body();
		return $fragments;
	}

	public static function ajax_update_qty() {
		check_ajax_referer( 'jnse-cart', 'nonce' );
		$key = isset( $_POST['key'] ) ? sanitize_text_field( wp_unslash( $_POST['key'] ) ) : '';
		$qty = isset( $_POST['qty'] ) ? max( 0, (int) $_POST['qty'] ) : 0;

		if ( $key && WC()->cart->get_cart_item( $key ) ) {
			if ( 0 === $qty ) {
				WC()->cart->remove_cart_item( $key );
			} else {
				$item = WC()->cart->get_cart_item( $key );
				$max  = $item['data']->get_max_purchase_quantity();
				if ( $max > 0 ) {
					$qty = min( $qty, $max );
				}
				WC()->cart->set_quantity( $key, $qty, true );
			}
			WC()->cart->calculate_totals();
		}
		// Sends { fragments, cart_hash } and exits.
		WC_AJAX::get_refreshed_fragments();
	}

	/* ---------------------------------------------------------------------
	 * Checkout progress indicator (classic checkout)
	 * ------------------------------------------------------------------- */

	public static function checkout_steps() {
		if ( ! JNSE_Settings::get( 'style_checkout' ) ) {
			return;
		}
		?>
		<ol class="jnse-steps" aria-label="<?php esc_attr_e( 'Progreso de compra', 'jn-shop' ); ?>">
			<li class="is-done"><a href="<?php echo esc_url( wc_get_cart_url() ); ?>"><span>1</span><?php esc_html_e( 'Carrito', 'jn-shop' ); ?></a></li>
			<li class="is-current" aria-current="step"><span>2</span><?php esc_html_e( 'Datos y pago', 'jn-shop' ); ?></li>
			<li><span>3</span><?php esc_html_e( 'Confirmación', 'jn-shop' ); ?></li>
		</ol>
		<?php
	}
}
