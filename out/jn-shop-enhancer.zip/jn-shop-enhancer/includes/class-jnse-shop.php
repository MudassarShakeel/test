<?php
defined( 'ABSPATH' ) || exit;

/**
 * AJAX shop: template override, shortcodes, product query endpoint, sidebar filters, product cards.
 */
class JNSE_Shop {

	/** URL query params (Spanish, and away from WP reserved vars like "cat" / "s"). */
	const P_CAT    = 'categoria';
	const P_SEARCH = 'buscar';
	const P_ORDER  = 'orden';
	const P_MIN    = 'precio_min';
	const P_MAX    = 'precio_max';
	const P_STOCK  = 'disponible';
	const P_SALE   = 'oferta';

	public static function init() {
		add_shortcode( 'jn_shop', array( __CLASS__, 'shortcode' ) );
		add_shortcode( 'jn_shop_home', array( __CLASS__, 'shortcode_home' ) );
		add_filter( 'template_include', array( __CLASS__, 'template' ), 999 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ), 20 );
		add_filter( 'body_class', array( __CLASS__, 'body_class' ) );

		// WooCommerce AJAX endpoint (?wc-ajax=jnse_products) — lighter than admin-ajax.
		add_action( 'wc_ajax_jnse_products', array( __CLASS__, 'ajax_products' ) );

		// Keep cached category tree fresh.
		foreach ( array( 'created_product_cat', 'edited_product_cat', 'delete_product_cat', 'woocommerce_update_product', 'woocommerce_new_product', 'set_object_terms' ) as $h ) {
			add_action( $h, array( __CLASS__, 'flush_cache' ) );
		}
	}

	public static function flush_cache() {
		delete_transient( 'jnse_cat_tree' );
		delete_transient( 'jnse_price_range' );
	}

	/* ---------------------------------------------------------------------
	 * Page takeover
	 * ------------------------------------------------------------------- */

	public static function is_takeover() {
		if ( is_admin() || ! function_exists( 'is_shop' ) ) {
			return false;
		}
		if ( JNSE_Settings::get( 'replace_shop' ) && is_shop() && ! is_search() ) {
			return true;
		}
		if ( JNSE_Settings::get( 'replace_cat_pages' ) && is_product_category() ) {
			return true;
		}
		return false;
	}

	public static function template( $template ) {
		if ( self::is_takeover() ) {
			return JNSE_DIR . 'templates/shop-page.php';
		}
		return $template;
	}

	public static function body_class( $classes ) {
		if ( self::is_takeover() ) {
			$classes[] = 'jnse-shop-page';
		}
		return $classes;
	}

	protected static function register() {
		if ( ! wp_style_is( 'jnse-shop', 'registered' ) ) {
			wp_register_style( 'jnse-shop', JNSE_URL . 'assets/css/shop.css', array(), JNSE_VERSION );
		}
		if ( ! wp_script_is( 'jnse-shop', 'registered' ) ) {
			wp_register_script( 'jnse-shop', JNSE_URL . 'assets/js/shop.js', array( 'jquery', 'wc-add-to-cart' ), JNSE_VERSION, true );
		}
	}

	public static function register_assets() {
		self::register();
		if ( self::is_takeover() ) {
			self::enqueue();
		}
	}

	public static function enqueue() {
		static $done = false;
		if ( $done ) {
			return;
		}
		$done = true;
		// Shortcodes can render before wp_enqueue_scripts (block themes), so register here too.
		self::register();
		wp_enqueue_style( 'jnse-shop' );
		wp_enqueue_script( 'wc-add-to-cart' );
		wp_enqueue_script( 'jnse-shop' );
		wp_localize_script( 'jnse-shop', 'JNSE_SHOP', array(
			'endpoint' => WC_AJAX::get_endpoint( 'jnse_products' ),
			'shopUrl'  => wc_get_page_permalink( 'shop' ),
			'infinite' => (int) JNSE_Settings::get( 'infinite_scroll' ),
			'params'   => array(
				'cat'    => self::P_CAT,
				'search' => self::P_SEARCH,
				'order'  => self::P_ORDER,
				'min'    => self::P_MIN,
				'max'    => self::P_MAX,
				'stock'  => self::P_STOCK,
				'sale'   => self::P_SALE,
			),
			'i18n'     => array(
				'error' => __( 'No se pudieron cargar los productos. Inténtalo de nuevo.', 'jn-shop' ),
			),
		) );
	}

	/* ---------------------------------------------------------------------
	 * State & query
	 * ------------------------------------------------------------------- */

	public static function sort_options() {
		return array(
			'menu_order' => __( 'Relevancia', 'jn-shop' ),
			'popularity' => __( 'Más vendidos', 'jn-shop' ),
			'date'       => __( 'Novedades', 'jn-shop' ),
			'price'      => __( 'Precio: menor a mayor', 'jn-shop' ),
			'price-desc' => __( 'Precio: mayor a menor', 'jn-shop' ),
			'rating'     => __( 'Mejor valorados', 'jn-shop' ),
		);
	}

	public static function sanitize_state( $src ) {
		$orderby = sanitize_key( $src['orderby'] ?? '' );
		$allowed = array_keys( self::sort_options() );
		if ( ! in_array( $orderby, $allowed, true ) ) {
			$orderby = get_option( 'woocommerce_default_catalog_orderby', 'menu_order' );
			if ( ! in_array( $orderby, $allowed, true ) ) {
				$orderby = 'menu_order';
			}
		}
		$num = function ( $v ) {
			$v = str_replace( ',', '.', (string) $v );
			return ( '' !== $v && is_numeric( $v ) && $v >= 0 ) ? (float) $v : '';
		};
		$per = absint( $src['per_page'] ?? 0 );
		return array(
			'cat'      => sanitize_title( wp_unslash( $src['cat'] ?? '' ) ),
			'search'   => mb_substr( sanitize_text_field( wp_unslash( $src['search'] ?? '' ) ), 0, 80 ),
			'orderby'  => $orderby,
			'page'     => max( 1, absint( $src['page'] ?? 1 ) ),
			'min'      => $num( $src['min'] ?? '' ),
			'max'      => $num( $src['max'] ?? '' ),
			'stock'    => ! empty( $src['stock'] ) ? 1 : 0,
			'sale'     => ! empty( $src['sale'] ) ? 1 : 0,
			'per_page' => $per ? min( 100, $per ) : (int) JNSE_Settings::get( 'per_page' ),
		);
	}

	/**
	 * @return WP_Query
	 */
	public static function query( array $state ) {
		$hidden = array( '' !== $state['search'] ? 'exclude-from-search' : 'exclude-from-catalog' );
		if ( $state['stock'] || 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ) {
			$hidden[] = 'outofstock';
		}

		$tax_query = array(
			'relation' => 'AND',
			array(
				'taxonomy' => 'product_visibility',
				'field'    => 'name',
				'terms'    => $hidden,
				'operator' => 'NOT IN',
			),
		);
		if ( '' !== $state['cat'] ) {
			$tax_query[] = array(
				'taxonomy'         => 'product_cat',
				'field'            => 'slug',
				'terms'            => array( $state['cat'] ),
				'include_children' => true,
			);
		}

		$args = array(
			'post_type'           => 'product',
			'post_status'         => 'publish',
			'posts_per_page'      => $state['per_page'],
			'paged'               => $state['page'],
			'tax_query'           => $tax_query, // phpcs:ignore WordPress.DB.SlowDBQuery
			'ignore_sticky_posts' => true,
		);
		if ( '' !== $state['search'] ) {
			$args['s'] = $state['search'];
		}

		// Price filter (uses the stored _price meta; variable products match if any variation fits).
		if ( '' !== $state['min'] || '' !== $state['max'] ) {
			$min = '' !== $state['min'] ? $state['min'] : 0;
			$max = '' !== $state['max'] ? $state['max'] : PHP_INT_MAX;
			if ( $min > $max ) {
				list( $min, $max ) = array( $max, $min );
			}
			$args['meta_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery
				array(
					'key'     => '_price',
					'value'   => array( $min, $max ),
					'compare' => 'BETWEEN',
					'type'    => 'DECIMAL(10,2)',
				),
			);
		}

		if ( $state['sale'] ) {
			$ids              = wc_get_product_ids_on_sale();
			$args['post__in'] = $ids ? array_map( 'absint', $ids ) : array( 0 );
		}

		// Let WooCommerce build the ordering (handles price/popularity/rating lookup tables).
		$parts    = explode( '-', $state['orderby'] );
		$order    = isset( $parts[1] ) ? strtoupper( $parts[1] ) : '';
		$ordering = WC()->query->get_catalog_ordering_args( $parts[0], $order );
		$args['orderby'] = $ordering['orderby'];
		$args['order']   = $ordering['order'];
		if ( ! empty( $ordering['meta_key'] ) ) {
			$args['meta_key'] = $ordering['meta_key']; // phpcs:ignore WordPress.DB.SlowDBQuery
		}
		if ( '' !== $state['search'] && 'menu_order' === $state['orderby'] ) {
			$args['orderby'] = 'relevance';
			$args['order']   = 'DESC';
		}

		$q = new WP_Query( apply_filters( 'jnse_query_args', $args, $state ) );
		WC()->query->remove_ordering_args();
		return $q;
	}

	/** Render product cards for a query. */
	public static function render_cards( WP_Query $q ) {
		ob_start();
		foreach ( $q->posts as $post ) {
			$product = wc_get_product( $post );
			if ( $product && $product->is_visible() ) {
				echo self::card( $product ); // phpcs:ignore -- escaped inside.
			}
		}
		return ob_get_clean();
	}

	public static function count_text( $total ) {
		/* translators: %s number of products */
		return sprintf( _n( 'Hay %s producto.', 'Hay %s productos.', $total, 'jn-shop' ), number_format_i18n( $total ) );
	}

	public static function ajax_products() {
		$state = self::sanitize_state( $_REQUEST ); // phpcs:ignore WordPress.Security.NonceVerification -- public read-only.
		$q     = self::query( $state );

		nocache_headers();
		wp_send_json_success( array(
			'html'      => self::render_cards( $q ),
			'total'     => (int) $q->found_posts,
			'page'      => $state['page'],
			'pages'     => (int) $q->max_num_pages,
			'countText' => self::count_text( (int) $q->found_posts ),
		) );
	}

	/* ---------------------------------------------------------------------
	 * Category tree & price range
	 * ------------------------------------------------------------------- */

	/** Nested category tree with roll-up counts (parent count includes its sub-categories). */
	public static function category_tree() {
		$cached = get_transient( 'jnse_cat_tree' );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
		if ( is_wp_error( $terms ) ) {
			return array();
		}
		$default  = (int) get_option( 'default_product_cat' );
		$children = array();
		$byid     = array();
		foreach ( $terms as $t ) {
			$byid[ $t->term_id ]        = $t;
			$children[ $t->parent ][] = $t->term_id;
		}
		$build = function ( $parent ) use ( &$build, $children, $byid, $default ) {
			$out = array();
			foreach ( $children[ $parent ] ?? array() as $id ) {
				$t = $byid[ $id ];
				if ( JNSE_Settings::get( 'hide_uncategorized' ) && $id === $default ) {
					continue;
				}
				$kids  = $build( $id );
				$count = (int) $t->count;
				foreach ( $kids as $k ) {
					$count += $k['count'];
				}
				$meta = get_term_meta( $id, 'product_count_product_cat', true );
				if ( '' !== $meta && (int) $meta > 0 ) {
					$count = (int) $meta; // WooCommerce's de-duplicated roll-up count.
				}
				if ( $count < 1 ) {
					continue; // hide empty categories
				}
				$ord   = get_term_meta( $id, 'order', true );
				$out[] = array(
					'order'    => ( '' === $ord || null === $ord ) ? 9999 : (int) $ord,
					'id'       => $id,
					'slug'     => $t->slug,
					'name'     => $t->name,
					'count'    => $count,
					'children' => $kids,
				);
			}
			// Categories ordered in Products → Categories (drag & drop) first, the rest alphabetically.
			usort( $out, function ( $a, $b ) {
				return $a['order'] <=> $b['order'] ?: strnatcasecmp( remove_accents( $a['name'] ), remove_accents( $b['name'] ) );
			} );
			return $out;
		};
		$tree = apply_filters( 'jnse_category_tree', $build( 0 ) );
		set_transient( 'jnse_cat_tree', $tree, HOUR_IN_SECONDS );
		return $tree;
	}

	/** Slugs of the active category and all its ancestors (to auto-expand the tree). */
	protected static function open_path( $slug ) {
		if ( '' === $slug ) {
			return array();
		}
		$term = get_term_by( 'slug', $slug, 'product_cat' );
		if ( ! $term ) {
			return array();
		}
		$ids = array_merge( array( $term->term_id ), get_ancestors( $term->term_id, 'product_cat', 'taxonomy' ) );
		return array_map( 'intval', $ids );
	}

	/** "BASES Y TOP" / "ilusion beauty" → "Bases y Top" / "Ilusion Beauty" (Spanish small words stay lowercase). */
	public static function nice_name( $name ) {
		$name  = html_entity_decode( $name, ENT_QUOTES, 'UTF-8' );
		$small = array( 'y', 'e', 'o', 'u', 'de', 'del', 'la', 'las', 'el', 'los', 'para', 'con', 'en', 'a', 'al', 'sin', 'por' );
		$name     = trim( $name );
		$all_caps = mb_strtoupper( $name, 'UTF-8' ) === $name;
		$orig     = preg_split( '/(\s+)/u', $name, -1, PREG_SPLIT_DELIM_CAPTURE );
		// Short brand codes stay as written: "DNK", "Lámparas UV".
		if ( 1 === count( $orig ) && mb_strlen( $name, 'UTF-8' ) <= 4 ) {
			return apply_filters( 'jnse_category_display_name', $name, $name );
		}
		$words = preg_split( '/(\s+)/u', mb_strtolower( $name, 'UTF-8' ), -1, PREG_SPLIT_DELIM_CAPTURE );
		$first = true;
		foreach ( $words as $i => $w ) {
			if ( '' === trim( $w ) ) {
				continue;
			}
			$o = $orig[ $i ];
			if ( ! $all_caps && mb_strlen( $o, 'UTF-8' ) <= 4 && mb_strtoupper( $o, 'UTF-8' ) === $o && preg_match( '/\p{Lu}/u', $o ) ) {
				$words[ $i ] = $o; // acronym inside a normal name
				$first       = false;
				continue;
			}
			if ( $first || ! in_array( $w, $small, true ) ) {
				$words[ $i ] = mb_strtoupper( mb_substr( $w, 0, 1, 'UTF-8' ), 'UTF-8' ) . mb_substr( $w, 1, null, 'UTF-8' );
			}
			$first = false;
		}
		return apply_filters( 'jnse_category_display_name', implode( '', $words ), $name );
	}

	protected static function render_tree( $nodes, $active, $open, $level = 0, $visible = true ) {
		if ( ! $nodes ) {
			return '';
		}
		$html = '<ul class="jnse-tree__list' . ( $level ? ' jnse-tree__sub' : '' ) . '"' . ( $visible ? '' : ' hidden' ) . '>';
		foreach ( $nodes as $n ) {
			$has     = ! empty( $n['children'] );
			$is_open = $has && in_array( $n['id'], $open, true );
			$is_act  = $n['slug'] === $active;
			$html   .= '<li class="jnse-tree__item' . ( $is_open ? ' is-open' : '' ) . '">';
			$html   .= '<div class="jnse-tree__row">';
			$html   .= sprintf(
				'<button type="button" class="jnse-tree__link%1$s" data-cat="%2$s" data-name="%3$s" aria-pressed="%4$s"><span class="jnse-tree__name">%5$s</span><span class="jnse-tree__count">%6$s</span></button>',
				$is_act ? ' is-active' : '',
				esc_attr( $n['slug'] ),
				esc_attr( self::nice_name( $n['name'] ) ),
				$is_act ? 'true' : 'false',
				esc_html( self::nice_name( $n['name'] ) ),
				esc_html( number_format_i18n( $n['count'] ) )
			);
			if ( $has ) {
				$html .= sprintf(
					'<button type="button" class="jnse-tree__toggle" aria-expanded="%1$s" aria-label="%2$s"><span aria-hidden="true"></span></button>',
					$is_open ? 'true' : 'false',
					/* translators: %s category */
					esc_attr( sprintf( __( 'Ver subcategorías de %s', 'jn-shop' ), self::nice_name( $n['name'] ) ) )
				);
			}
			$html .= '</div>';
			if ( $has ) {
				$html .= self::render_tree( $n['children'], $active, $open, $level + 1, $is_open );
			}
			$html .= '</li>';
		}
		return $html . '</ul>';
	}

	public static function price_range() {
		$r = get_transient( 'jnse_price_range' );
		if ( is_array( $r ) ) {
			return $r;
		}
		global $wpdb;
		$row = $wpdb->get_row( "SELECT MIN(min_price) AS lo, MAX(max_price) AS hi FROM {$wpdb->wc_product_meta_lookup} WHERE min_price > 0" ); // phpcs:ignore
		$r   = array(
			'min' => $row && $row->lo ? floor( (float) $row->lo ) : 0,
			'max' => $row && $row->hi ? ceil( (float) $row->hi ) : 0,
		);
		set_transient( 'jnse_price_range', $r, HOUR_IN_SECONDS );
		return $r;
	}

	/* ---------------------------------------------------------------------
	 * Shortcodes
	 * ------------------------------------------------------------------- */

	/** [jn_shop category="slug" per_page="24"] — full shop with sidebar. */
	public static function shortcode( $atts ) {
		$atts = shortcode_atts( array( 'category' => '', 'per_page' => '', 'title' => '' ), $atts, 'jn_shop' );
		self::enqueue();
		return self::render( array(
			'mode'     => 'shop',
			'category' => $atts['category'],
			'per_page' => $atts['per_page'],
			'title'    => $atts['title'],
		) );
	}

	/**
	 * [jn_shop_home limit="8" columns="4" title="Nuestros productos" button="Ver todos los productos" category="" orderby="date" filters="yes"]
	 * Home-page block: same sidebar filters + product cards, a fixed number of products and a button to the shop.
	 */
	public static function shortcode_home( $atts ) {
		$atts = shortcode_atts( array(
			'limit'    => 8,
			'columns'  => '',
			'title'    => __( 'Nuestros productos', 'jn-shop' ),
			'button'   => __( 'Ver todos los productos', 'jn-shop' ),
			'category' => '',
			'orderby'  => '',
			'filters'  => 'yes',
		), $atts, 'jn_shop_home' );
		self::enqueue();
		return self::render( array(
			'mode'     => 'home',
			'category' => $atts['category'],
			'per_page' => max( 1, min( 48, (int) $atts['limit'] ) ),
			'columns'  => (int) $atts['columns'],
			'title'    => $atts['title'],
			'button'   => $atts['button'],
			'orderby'  => $atts['orderby'],
			'filters'  => 'no' !== strtolower( $atts['filters'] ),
		) );
	}

	/* ---------------------------------------------------------------------
	 * Markup
	 * ------------------------------------------------------------------- */

	/** Full UI. The first page is rendered server-side (fast first paint, SEO, no-JS fallback). */
	public static function render( $opts = array() ) {
		$opts = wp_parse_args( $opts, array(
			'mode'     => 'shop',
			'category' => '',
			'per_page' => '',
			'columns'  => 0,
			'title'    => '',
			'button'   => '',
			'orderby'  => '',
			'filters'  => true,
		) );
		$home = 'home' === $opts['mode'];

		// phpcs:disable WordPress.Security.NonceVerification
		$src = $home ? array() : $_GET;
		$state = self::sanitize_state( array(
			'cat'      => $src[ self::P_CAT ] ?? $opts['category'],
			'search'   => $src[ self::P_SEARCH ] ?? '',
			'orderby'  => $src[ self::P_ORDER ] ?? $opts['orderby'],
			// Price / stock / sale filters are not shown in the UI, so never apply them from the URL.
			'min'      => '',
			'max'      => '',
			'stock'    => 0,
			'sale'     => 0,
			'per_page' => $opts['per_page'],
			'page'     => 1,
		) );
		// phpcs:enable
		if ( ! $home && '' === $state['cat'] && is_product_category() ) {
			$state['cat'] = get_queried_object()->slug;
		}

		$q        = self::query( $state );
		$tree     = self::category_tree();
		$open     = self::open_path( $state['cat'] );
		$title    = $opts['title'] ?: JNSE_Settings::get( 'shop_title' );
		if ( ! $home && is_product_category() ) {
			$title = self::nice_name( single_term_title( '', false ) );
		}
		$subtitle = $home ? '' : JNSE_Settings::get( 'shop_subtitle' );
		$uid      = 'jnse-' . wp_unique_id();
		$style    = $opts['columns'] ? ' style="--jn-cols:' . (int) $opts['columns'] . '"' : '';
		$active_n = (int) ( '' !== $state['cat'] ) + (int) ( '' !== $state['search'] );

		ob_start();
		?>
		<div class="jnse jnse--<?php echo esc_attr( $opts['mode'] ); ?><?php echo $opts['filters'] ? '' : ' jnse--nofilters'; ?>" data-jnse<?php echo $style; // phpcs:ignore ?>
			data-mode="<?php echo esc_attr( $opts['mode'] ); ?>"
			data-cat="<?php echo esc_attr( $state['cat'] ); ?>"
			data-search="<?php echo esc_attr( $state['search'] ); ?>"
			data-orderby="<?php echo esc_attr( $state['orderby'] ); ?>"
			data-min="<?php echo esc_attr( $state['min'] ); ?>"
			data-max="<?php echo esc_attr( $state['max'] ); ?>"
			data-stock="<?php echo (int) $state['stock']; ?>"
			data-sale="<?php echo (int) $state['sale']; ?>"
			data-per-page="<?php echo (int) $state['per_page']; ?>"
			data-pages="<?php echo (int) $q->max_num_pages; ?>">

			<div class="jnse-layout">
				<?php if ( $opts['filters'] ) : ?>
				<aside class="jnse-side" id="<?php echo esc_attr( $uid ); ?>-side" data-jnse-side aria-label="<?php esc_attr_e( 'Filtros', 'jn-shop' ); ?>">

					<div class="jnse-box">
						<h2 class="jnse-box__title"><?php esc_html_e( 'Categorías', 'jn-shop' ); ?></h2>
						<nav class="jnse-tree">
							<div class="jnse-tree__row jnse-tree__row--all">
								<button type="button" class="jnse-tree__link<?php echo '' === $state['cat'] ? ' is-active' : ''; ?>" data-cat="" data-name="" aria-pressed="<?php echo '' === $state['cat'] ? 'true' : 'false'; ?>">
									<span class="jnse-tree__name"><?php esc_html_e( 'Todos los productos', 'jn-shop' ); ?></span>
								</button>
							</div>
							<?php echo self::render_tree( $tree, $state['cat'], $open ); // phpcs:ignore ?>
						</nav>
					</div>

					<button type="button" class="jnse-clear" data-jnse-reset <?php echo $active_n ? '' : 'hidden'; ?>><?php esc_html_e( 'Limpiar filtros', 'jn-shop' ); ?></button>
				</aside>
				<?php endif; ?>

				<div class="jnse-main-col">
					<header class="jnse-head">
						<?php if ( $title ) : ?>
							<?php if ( $home ) : ?>
								<h2 class="jnse-title" data-jnse-title data-default="<?php echo esc_attr( $title ); ?>"><?php echo esc_html( $title ); ?></h2>
							<?php else : ?>
								<h1 class="jnse-title" data-jnse-title data-default="<?php echo esc_attr( JNSE_Settings::get( 'shop_title' ) ); ?>"><?php echo esc_html( $title ); ?></h1>
							<?php endif; ?>
						<?php endif; ?>
						<?php if ( $subtitle ) : ?>
							<p class="jnse-subtitle"><?php echo esc_html( $subtitle ); ?></p>
						<?php endif; ?>
					</header>

					<div class="jnse-toolbar">
						<p class="jnse-count" data-jnse-count aria-live="polite"><?php echo esc_html( self::count_text( (int) $q->found_posts ) ); ?></p>
						<div class="jnse-search"><?php echo self::search_field( $uid . '-q', $state['search'] ); // phpcs:ignore ?></div>
						<div class="jnse-sort">
							<label for="<?php echo esc_attr( $uid ); ?>-sort"><?php esc_html_e( 'Ordenar por:', 'jn-shop' ); ?></label>
							<div class="jnse-sort__select">
								<select id="<?php echo esc_attr( $uid ); ?>-sort" data-jnse-sort>
									<?php foreach ( self::sort_options() as $k => $label ) : ?>
										<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $state['orderby'], $k ); ?>><?php echo esc_html( $label ); ?></option>
									<?php endforeach; ?>
								</select>
							</div>
						</div>
						<div class="jnse-view" role="group" aria-label="<?php esc_attr_e( 'Vista', 'jn-shop' ); ?>">
							<button type="button" class="is-active" data-jnse-view="grid" aria-pressed="true" aria-label="<?php esc_attr_e( 'Cuadrícula', 'jn-shop' ); ?>"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/></svg></button>
							<button type="button" data-jnse-view="list" aria-pressed="false" aria-label="<?php esc_attr_e( 'Lista', 'jn-shop' ); ?>"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="5" width="5" height="5" rx="1"/><rect x="4" y="14" width="5" height="5" rx="1"/><path d="M12 7.5h8M12 16.5h8"/></svg></button>
						</div>
					</div>

					<div class="jnse-grid" data-jnse-grid aria-busy="false"><?php echo self::render_cards( $q ); // phpcs:ignore ?></div>

					<div class="jnse-empty" data-jnse-empty <?php echo $q->found_posts ? 'hidden' : ''; ?>>
						<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
						<p class="jnse-empty__title"><?php esc_html_e( 'No encontramos productos', 'jn-shop' ); ?></p>
						<p><?php esc_html_e( 'Prueba con otra palabra o elige otra categoría.', 'jn-shop' ); ?></p>
						<button type="button" class="jnse-btn jnse-btn--ghost" data-jnse-reset><?php esc_html_e( 'Ver todos los productos', 'jn-shop' ); ?></button>
					</div>

					<div class="jnse-more">
						<?php if ( $home ) : ?>
							<a class="jnse-btn jnse-btn--all" data-jnse-all href="<?php echo esc_url( self::shop_link( $state ) ); ?>"><?php echo esc_html( $opts['button'] ); ?> <span aria-hidden="true">→</span></a>
						<?php else : ?>
							<button type="button" class="jnse-btn jnse-btn--ghost" data-jnse-more <?php echo $q->max_num_pages > 1 ? '' : 'hidden'; ?>><?php esc_html_e( 'Cargar más productos', 'jn-shop' ); ?></button>
							<div class="jnse-sentinel" data-jnse-sentinel aria-hidden="true"></div>
							<noscript>
								<?php if ( $q->max_num_pages > 1 ) {
									echo '<p><a href="' . esc_url( get_pagenum_link( 2 ) ) . '">' . esc_html__( 'Página siguiente', 'jn-shop' ) . '</a></p>';
								} ?>
							</noscript>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	protected static function search_field( $id, $value ) {
		ob_start();
		?>
		<svg class="jnse-search__icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
		<label class="screen-reader-text" for="<?php echo esc_attr( $id ); ?>"><?php esc_html_e( 'Buscar productos', 'jn-shop' ); ?></label>
		<input id="<?php echo esc_attr( $id ); ?>" type="search" autocomplete="off" enterkeyhint="search"
			placeholder="<?php esc_attr_e( 'Buscar productos…', 'jn-shop' ); ?>"
			value="<?php echo esc_attr( $value ); ?>" data-jnse-search>
		<span class="jnse-spinner" aria-hidden="true"></span>
		<button type="button" class="jnse-search__clear" data-jnse-clear aria-label="<?php esc_attr_e( 'Borrar búsqueda', 'jn-shop' ); ?>" <?php echo '' === $value ? 'hidden' : ''; ?>>&times;</button>
		<?php
		return ob_get_clean();
	}

	/** Shop URL carrying the current filters (used by the home "view all" button). */
	public static function shop_link( $state ) {
		$args = array_filter( array(
			self::P_CAT    => $state['cat'],
			self::P_SEARCH => $state['search'],
			self::P_MIN    => $state['min'],
			self::P_MAX    => $state['max'],
			self::P_STOCK  => $state['stock'] ?: '',
			self::P_SALE   => $state['sale'] ?: '',
		), function ( $v ) { return '' !== $v && null !== $v; } );
		return add_query_arg( $args, wc_get_page_permalink( 'shop' ) );
	}

	/** Max discount % for simple or variable products. */
	protected static function discount_percent( WC_Product $p ) {
		if ( ! $p->is_on_sale() ) {
			return 0;
		}
		$max = 0;
		if ( $p->is_type( 'variable' ) ) {
			$prices = $p->get_variation_prices();
			foreach ( $prices['regular_price'] as $id => $reg ) {
				$sale = $prices['sale_price'][ $id ] ?? $reg;
				if ( $reg > 0 && $sale < $reg ) {
					$max = max( $max, ( $reg - $sale ) / $reg * 100 );
				}
			}
		} else {
			$reg  = (float) $p->get_regular_price();
			$sale = (float) $p->get_sale_price();
			if ( $reg > 0 && $sale > 0 && $sale < $reg ) {
				$max = ( $reg - $sale ) / $reg * 100;
			}
		}
		return (int) round( $max );
	}

	public static function card( WC_Product $p ) {
		$id        = $p->get_id();
		$link      = $p->get_permalink();
		$name      = $p->get_name();
		$img_id    = $p->get_image_id();
		$gallery   = $p->get_gallery_image_ids();
		$hover_id  = $gallery ? (int) $gallery[0] : 0;
		$in_stock  = $p->is_in_stock();
		$sizes     = '(max-width: 600px) 50vw, (max-width: 1024px) 33vw, 25vw';
		$img_attrs = array( 'class' => 'jnse-card__img', 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => $sizes, 'alt' => $name );

		// Category label (skip "Uncategorized").
		$cat_name = '';
		$terms    = get_the_terms( $id, 'product_cat' );
		if ( $terms && ! is_wp_error( $terms ) ) {
			$default = (int) get_option( 'default_product_cat' );
			foreach ( $terms as $t ) {
				if ( (int) $t->term_id !== $default ) {
					$cat_name = $t->name;
					break;
				}
			}
		}

		$classes = array( 'jnse-card' );
		if ( ! $in_stock ) {
			$classes[] = 'is-out';
		}
		if ( $hover_id ) {
			$classes[] = 'has-hover';
		}

		ob_start();
		?>
		<article class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" data-id="<?php echo (int) $id; ?>">
			<a class="jnse-card__media" href="<?php echo esc_url( $link ); ?>" tabindex="-1" aria-hidden="true">
				<?php
				echo $img_id
					? wp_get_attachment_image( $img_id, 'woocommerce_single', false, $img_attrs )
					: wc_placeholder_img( 'woocommerce_single', array( 'class' => 'jnse-card__img' ) );
				if ( $hover_id ) {
					echo wp_get_attachment_image( $hover_id, 'woocommerce_single', false, array_merge( $img_attrs, array( 'class' => 'jnse-card__img jnse-card__img--hover', 'alt' => '' ) ) );
				}
				?>
				<span class="jnse-badges">
					<?php if ( ! $in_stock ) : ?>
						<span class="jnse-badge jnse-badge--out"><?php esc_html_e( 'Agotado', 'jn-shop' ); ?></span>
					<?php elseif ( $p->is_on_sale() ) : $pct = self::discount_percent( $p ); ?>
						<span class="jnse-badge jnse-badge--sale"><?php echo $pct ? esc_html( '-' . $pct . '%' ) : esc_html__( 'Oferta', 'jn-shop' ); ?></span>
					<?php endif; ?>
					<?php if ( $p->is_featured() && $in_stock ) : ?>
						<span class="jnse-badge jnse-badge--hot"><?php esc_html_e( 'Destacado', 'jn-shop' ); ?></span>
					<?php endif; ?>
				</span>
			</a>

			<div class="jnse-card__body">
				<?php if ( $cat_name ) : ?>
					<span class="jnse-card__cat"><?php echo esc_html( $cat_name ); ?></span>
				<?php endif; ?>
				<h3 class="jnse-card__title"><a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $name ); ?></a></h3>
				<?php if ( wc_review_ratings_enabled() && $p->get_average_rating() > 0 ) : ?>
					<div class="jnse-card__rating"><?php echo wc_get_rating_html( $p->get_average_rating(), $p->get_rating_count() ); // phpcs:ignore ?></div>
				<?php endif; ?>
				<div class="jnse-card__price"><?php echo $p->get_price_html(); // phpcs:ignore ?></div>
				<div class="jnse-card__actions"><?php echo self::button( $p ); // phpcs:ignore ?></div>
			</div>
		</article>
		<?php
		return apply_filters( 'jnse_card_html', ob_get_clean(), $p );
	}

	protected static function button( WC_Product $p ) {
		$bag = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 7h12l-1 13H7L6 7Z"/><path d="M9 7a3 3 0 0 1 6 0"/></svg>';

		if ( $p->is_purchasable() && $p->is_in_stock() && $p->supports( 'ajax_add_to_cart' ) ) {
			return sprintf(
				'<a href="%1$s" data-quantity="1" data-product_id="%2$d" data-product_sku="%3$s" class="button add_to_cart_button ajax_add_to_cart jnse-btn jnse-btn--cart" rel="nofollow" aria-label="%4$s">%5$s<span>%6$s</span></a>',
				esc_url( $p->add_to_cart_url() ),
				$p->get_id(),
				esc_attr( $p->get_sku() ),
				/* translators: %s product name */
				esc_attr( sprintf( __( 'Añadir «%s» al carrito', 'jn-shop' ), $p->get_name() ) ),
				$bag,
				esc_html__( 'Añadir al carrito', 'jn-shop' )
			);
		}

		if ( ! $p->is_in_stock() ) {
			$label = __( 'Ver producto', 'jn-shop' );
		} elseif ( $p->is_type( 'variable' ) ) {
			$label = __( 'Elegir opciones', 'jn-shop' );
		} else {
			$label = $p->add_to_cart_text();
		}
		$href = $p->is_type( 'external' ) ? $p->add_to_cart_url() : $p->get_permalink();

		return sprintf(
			'<a href="%1$s" class="jnse-btn jnse-btn--ghost jnse-btn--cart">%2$s</a>',
			esc_url( $href ),
			esc_html( $label )
		);
	}
}
