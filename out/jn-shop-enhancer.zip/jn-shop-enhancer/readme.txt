=== Johanna Shop Enhancer ===
Version: 1.2.0
Requires: WordPress 6.0+, WooCommerce 7.0+, PHP 7.4+

AJAX shop page for WooCommerce with a left sidebar category tree (with
+/- sub-categories), search + sorting in the toolbar, grid/list view, infinite
scroll, AJAX add-to-cart with a slide-in mini-cart, and restyled cart/checkout.
On mobile the categories are shown at the top of the page (no dropdown).

== Install ==
1. Plugins > Add New > Upload Plugin > choose jn-shop-enhancer.zip > Activate.
2. WooCommerce > Johanna Shop: paste your theme hex colors and save.
3. Open /tienda/ - the shop page is replaced automatically.
4. If you use a page cache (LiteSpeed, WP Rocket, Cloudflare APO...), purge it.

== Settings (WooCommerce > Johanna Shop) ==
- Colors: primary, hover, accent, text, muted, background, surface, border, sale.
- Fonts: "inherit" keeps your theme fonts.
- Products per load, columns (desktop/tablet/mobile), image shape.
- Hide "Uncategorized" category.
- Infinite scroll on/off (a "Load more" button is always the fallback).
- Mini-cart drawer, free-shipping progress bar threshold.
- Restyle cart / checkout on/off.

== Header cart icon ==
Add the CSS class "jnse-open-cart" to any header icon/button (e.g. Elementor
widget > Advanced > CSS Classes) and clicking it opens the mini-cart drawer.

== Home page shortcode ==
[jn_shop_home limit="8" title="Nuestros productos" button="Ver todos los productos"]
Options: limit, columns, category="slug", orderby="date|popularity|price|price-desc|rating",
filters="no" (products only, no sidebar). The button opens the shop with the
visitor's current filters applied.

== Category order ==
Drag & drop categories in Products > Categories to set their order in the sidebar.
Categories without a set order are listed after them, alphabetically.

== Manual placement ==
Turn off "Replace the WooCommerce shop page" and use the shortcode [jn_shop]
(or [jn_shop category="slug"]) in any page or Elementor Shortcode widget.

== Shareable URLs ==
/tienda/?categoria=slug&buscar=texto&orden=price
orden: menu_order, popularity, date, price, price-desc, rating

== Developer hooks ==
jnse_query_args (filter), jnse_category_args (filter), jnse_card_html (filter),
jnse:rendered (jQuery event on document.body after the grid updates).
