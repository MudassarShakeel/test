<?php
/**
 * Shop page template used by Johanna Shop Enhancer.
 * Keeps the theme's header & footer, replaces only the shop content.
 */
defined( 'ABSPATH' ) || exit;

if ( function_exists( 'wp_is_block_theme' ) && wp_is_block_theme() ) : ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="wp-site-blocks">
	<?php block_template_part( 'header' ); ?>
	<main id="jnse-main" class="jnse-main"><?php echo JNSE_Shop::render(); // phpcs:ignore ?></main>
	<?php block_template_part( 'footer' ); ?>
</div>
<?php wp_footer(); ?>
</body>
</html>
<?php
else :
	get_header( 'shop' );
	?>
	<main id="jnse-main" class="jnse-main"><?php echo JNSE_Shop::render(); // phpcs:ignore ?></main>
	<?php
	get_footer( 'shop' );
endif;
