<?php
/**
 * Plugin Name:       Johanna Shop Enhancer
 * Description:       AJAX shop page for WooCommerce: sidebar category tree & filters, live search, sorting, load-more grid, AJAX add-to-cart with side mini-cart, and restyled cart & checkout pages that override the theme.
 * Version:           1.2.0
 * Author:            Mc Starters
 * Author URI:        https://mcstarters.com
 * Text Domain:       jn-shop
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * WC requires at least: 7.0
 * WC tested up to:   9.9
 */

defined( 'ABSPATH' ) || exit;

define( 'JNSE_VERSION', '1.2.0' );
define( 'JNSE_FILE', __FILE__ );
define( 'JNSE_DIR', plugin_dir_path( __FILE__ ) );
define( 'JNSE_URL', plugin_dir_url( __FILE__ ) );

// Declare compatibility with WooCommerce HPOS + cart/checkout blocks.
add_action( 'before_woocommerce_init', function () {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
	}
} );

add_action( 'plugins_loaded', function () {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', function () {
			echo '<div class="notice notice-error"><p><strong>Johanna Shop Enhancer</strong> requires WooCommerce to be active.</p></div>';
		} );
		return;
	}

	require_once JNSE_DIR . 'includes/class-jnse-settings.php';
	require_once JNSE_DIR . 'includes/class-jnse-shop.php';
	require_once JNSE_DIR . 'includes/class-jnse-cart.php';

	JNSE_Settings::init();
	JNSE_Shop::init();
	JNSE_Cart::init();
} );

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
	array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=jn-shop' ) ) . '">' . esc_html__( 'Settings', 'jn-shop' ) . '</a>' );
	return $links;
} );
